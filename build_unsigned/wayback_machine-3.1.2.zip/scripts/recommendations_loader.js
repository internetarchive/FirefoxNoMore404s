getDetails()
