window.onload = function () {
  var url = getUrlByParameter('url')
  get_tweets(url)
}
