window.onload = function(){
  var url = getUrlByParameter('url');
  populateBooks(url);
};
