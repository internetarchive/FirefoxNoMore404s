let has_book = document.getElementById("has_book");

has_book.addEventListener("click", function(){
  let mailInfo = document.getElementById("mail_info");
  mailInfo.setAttribute("style", "display:block;")
});
