window.onload = createPage;
