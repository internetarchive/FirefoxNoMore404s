window.onload = url_getter;
