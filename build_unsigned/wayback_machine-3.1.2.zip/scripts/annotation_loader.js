get_annotations('domain');
get_annotations('url');
$('.active').click()
